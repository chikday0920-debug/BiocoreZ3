/* =========================================================
   BioCoreZ3 — Shared interactivity
   ========================================================= */

document.addEventListener('DOMContentLoaded', () => {

  /* ---------- Mobile sidebar ---------- */
  const menuToggle = document.querySelector('[data-menu-toggle]');
  const sidebar = document.querySelector('.sidebar');
  const backdrop = document.querySelector('.sidebar-backdrop');
  if (menuToggle && sidebar) {
    menuToggle.addEventListener('click', () => {
      sidebar.classList.toggle('open');
      backdrop?.classList.toggle('show');
    });
    backdrop?.addEventListener('click', () => {
      sidebar.classList.remove('open');
      backdrop.classList.remove('show');
    });
  }

  /* ---------- Active nav link ---------- */
  const current = (location.pathname.split('/').pop() || 'index.html');
  document.querySelectorAll('.nav-link[data-page]').forEach(link => {
    if (link.dataset.page === current) link.classList.add('active');
  });

  /* ---------- Password show/hide ---------- */
  document.querySelectorAll('.toggle-eye').forEach(btn => {
    btn.addEventListener('click', () => {
      const input = btn.parentElement.querySelector('input');
      if (!input) return;
      const isPass = input.type === 'password';
      input.type = isPass ? 'text' : 'password';
      btn.querySelector('i')?.classList.toggle('fa-eye');
      btn.querySelector('i')?.classList.toggle('fa-eye-slash');
    });
  });

  /* ---------- Decorative tab groups (no panel switching) ---------- */
  document.querySelectorAll('.tabs:not([data-tabs])').forEach(group => {
    const buttons = group.querySelectorAll('.tab-btn');
    buttons.forEach(btn => {
      if (btn.hasAttribute('data-filter-type')) return; // handled by gaiadex filter logic
      btn.addEventListener('click', () => {
        buttons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
      });
    });
  });

  /* ---------- Generic tabs ---------- */
  document.querySelectorAll('[data-tabs]').forEach(tabGroup => {
    const targetSel = tabGroup.dataset.tabs;
    const buttons = tabGroup.querySelectorAll('.tab-btn');
    buttons.forEach(btn => {
      btn.addEventListener('click', () => {
        buttons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        document.querySelectorAll(`${targetSel} > [data-tab-panel]`).forEach(p => {
          p.style.display = p.dataset.tabPanel === btn.dataset.tab ? '' : 'none';
        });
      });
    });
  });

  /* ---------- Toast ---------- */
  window.showToast = (msg, icon = 'fa-circle-check') => {
    let toast = document.querySelector('.toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.className = 'toast';
      document.body.appendChild(toast);
    }
    toast.innerHTML = `<i class="fa-solid ${icon}"></i> ${msg}`;
    toast.classList.add('show');
    clearTimeout(window.__toastTimer);
    window.__toastTimer = setTimeout(() => toast.classList.remove('show'), 2600);
  };

  /* ---------- Auth forms (demo, no backend) ---------- */
  const registerForm = document.querySelector('#registerForm');
  if (registerForm) {
    registerForm.addEventListener('submit', e => {
      e.preventDefault();
      const terms = registerForm.querySelector('#terms');
      if (terms && !terms.checked) {
        showToast('Debes aceptar los Términos de Servicio.', 'fa-triangle-exclamation');
        return;
      }
      showToast('Cuenta creada. Redirigiendo…', 'fa-circle-check');
      setTimeout(() => location.href = 'index.html', 1200);
    });
  }
  const loginForm = document.querySelector('#loginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', e => {
      e.preventDefault();
      showToast('Verificando credenciales…', 'fa-shield-halved');
      setTimeout(() => location.href = 'dashboard.html', 1000);
    });
  }

  /* ---------- Gaiadex filters ---------- */
  const gaiadexGrid = document.querySelector('[data-gaiadex-grid]');
  if (gaiadexGrid) {
    const cards = [...gaiadexGrid.querySelectorAll('.species-card')];
    const filterBtns = document.querySelectorAll('[data-filter-type]');
    const searchInput = document.querySelector('#gaiadexSearch');
    const rareRange = document.querySelector('#rareRange');
    const emptyState = document.querySelector('[data-gaiadex-empty]');

    const applyFilters = () => {
      const activeType = document.querySelector('[data-filter-type].active')?.dataset.filterType || 'todas';
      const query = (searchInput?.value || '').toLowerCase().trim();
      let visible = 0;
      cards.forEach(card => {
        const type = card.dataset.type;
        const name = card.dataset.name.toLowerCase();
        const matchesType = activeType === 'todas' || type === activeType;
        const matchesQuery = !query || name.includes(query);
        const show = matchesType && matchesQuery;
        card.style.display = show ? '' : 'none';
        if (show) visible++;
      });
      if (emptyState) emptyState.style.display = visible === 0 ? '' : 'none';
    };

    filterBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        filterBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        applyFilters();
      });
    });
    searchInput?.addEventListener('input', applyFilters);
    rareRange?.addEventListener('input', applyFilters);

    document.querySelectorAll('[data-clear-filters]').forEach(b => b.addEventListener('click', () => {
      filterBtns.forEach(btn => btn.classList.remove('active'));
      document.querySelector('[data-filter-type="todas"]')?.classList.add('active');
      if (searchInput) searchInput.value = '';
      document.querySelectorAll('input[type="checkbox"]').forEach(c => c.checked = false);
      applyFilters();
    }));
  }

  /* ---------- Scanner demo ---------- */
  const scanBtn = document.querySelector('#scanTrigger');
  if (scanBtn) {
    scanBtn.addEventListener('click', () => {
      const statusEl = document.querySelector('#scanStatus');
      const confEl = document.querySelector('#confValue');
      if (!statusEl) return;
      statusEl.innerHTML = '<div class="spin-ring"></div><b>Analizando muestra…</b><span>El motor neuronal está identificando la especie.</span>';
      let conf = 0;
      const timer = setInterval(() => {
        conf += Math.random() * 18;
        if (conf >= 97) {
          conf = 97;
          clearInterval(timer);
          statusEl.innerHTML = '<i class="fa-solid fa-circle-check" style="font-size:2rem;color:#c3f53c"></i><b>Especie identificada</b><span>Solanum tuberosum — Papa criolla</span>';
        }
        if (confEl) confEl.textContent = Math.round(conf) + '%';
      }, 260);
    });
  }

  /* ---------- Store: add to cart ---------- */
  document.querySelectorAll('[data-buy]').forEach(btn => {
    btn.addEventListener('click', () => {
      showToast(`"${btn.dataset.buy}" añadido a tu inventario.`, 'fa-bag-shopping');
    });
  });

  /* ---------- Settings save ---------- */
  document.querySelector('#saveSettings')?.addEventListener('click', () => {
    showToast('Cambios guardados correctamente.', 'fa-floppy-disk');
  });

  /* ---------- Charts ---------- */
  if (window.Chart) {
    const teal = 'rgba(20,184,166,1)';
    const lime = 'rgba(195,245,60,1)';

    const statsCanvas = document.querySelector('#statsChart');
    if (statsCanvas) {
      new Chart(statsCanvas, {
        type: 'line',
        data: {
          labels: ['Jan','Feb','Mar','Apr','May','Jun'],
          datasets: [
            {
              label: 'Escaneos',
              data: [45,52,49,68,82,88],
              borderColor: lime, backgroundColor: 'rgba(195,245,60,.15)',
              tension: .45, fill: true, pointRadius: 0, borderWidth: 3
            },
            {
              label: 'Especies nuevas',
              data: [20,24,22,30,34,40],
              borderColor: teal, backgroundColor: 'rgba(20,184,166,.12)',
              tension: .45, fill: true, pointRadius: 0, borderWidth: 3
            }
          ]
        },
        options: {
          plugins: { legend: { display: false } },
          scales: {
            y: { min: 0, max: 100, grid: { color: 'rgba(255,255,255,.15)' }, ticks: { color: 'rgba(255,255,255,.8)' } },
            x: { grid: { display: false }, ticks: { color: 'rgba(255,255,255,.8)' } }
          }
        }
      });
    }

    const contribCanvas = document.querySelector('#contribChart');
    if (contribCanvas) {
      new Chart(contribCanvas, {
        type: 'line',
        data: {
          labels: ['Tue','Wed','Thu','Fri','Sat','Sun'],
          datasets: [{
            data: [40, 65, 50, 78, 60, 90, 72],
            borderColor: '#0e5c46', backgroundColor: 'rgba(14,92,70,.12)',
            tension: .5, fill: true, pointRadius: 0, borderWidth: 3
          }]
        },
        options: {
          plugins: { legend: { display: false } },
          scales: {
            y: { display: false },
            x: { grid: { display: false }, ticks: { color: 'rgba(15,46,38,.6)', font: { size: 10 } } }
          }
        }
      });
    }
  }
});
